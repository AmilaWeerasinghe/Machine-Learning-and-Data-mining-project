python folder 
include the python notebook which contains the project source code.


weka folder 
contains the weka process data and output files for the randomforest and j48decision tree models